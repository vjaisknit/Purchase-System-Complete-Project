﻿using PurchaseSystem.Common;
using PurchaseSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PurchaseSystem.Controllers
{
    [Authorize(Roles = "Admin,GeneralStore,ClothStore")]
    public class CustomerController : Controller
    {
        ApplicationDbContext _db = new ApplicationDbContext();
        public CustomerController()
        {

        }
        // GET: Customer
        public ActionResult Index()
        {
            IEnumerable<CustomerMst> CustomerList;
            if (User.IsInRole("Admin"))
            {
                 CustomerList = _db.CustomerMsts.ToList();
               
            }
            else
            {
                CustomerList = _db.CustomerMsts.Where(a=>a.Username==User.Identity.Name).ToList();
            }
            return View(CustomerList);
        }

        [HttpGet]
        public ActionResult SaveUpdateCustomer()
        {
            return View();
        }

        public ActionResult Edit(int id)
        {
            CustomerMst cust;
            if (User.IsInRole("Admin"))
            {
                cust = _db.CustomerMsts.FirstOrDefault(a => a.pk_Custid == id);
            }
            else
            {
                cust = _db.CustomerMsts.FirstOrDefault(a => a.pk_Custid == id && a.Username==User.Identity.Name);
            }
                return View("SaveUpdateCustomer", cust);
        }
        public ActionResult Delete(int id)
        {
            CustomerMst cust;
            if (User.IsInRole("Admin"))
            {
                cust = _db.CustomerMsts.FirstOrDefault(a => a.pk_Custid == id);
            }
            else
            {
                cust = _db.CustomerMsts.FirstOrDefault(a => a.pk_Custid == id && a.Username == User.Identity.Name);
            }
            if (cust == null)
                HttpNotFound();

            _db.CustomerMsts.Remove(cust);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }


        [HttpPost]
        public ActionResult SaveUpdateCustomer(CustomerMst customer )
        {
            
            if(customer.pk_Custid==0)
            {
                customer.Username = User.Identity.Name;
                _db.CustomerMsts.Add(customer);
                _db.SaveChanges();
            }
            else
            {
                if (User.IsInRole("Admin"))
                {
                    var custInDb = _db.CustomerMsts.FirstOrDefault(a => a.pk_Custid == customer.pk_Custid );
                    custInDb.Name = customer.Name;
                    custInDb.MobNo = customer.MobNo;

                }
                else
                {
                    var custInDb = _db.CustomerMsts.FirstOrDefault(a => a.pk_Custid == customer.pk_Custid && a.Username == User.Identity.Name);
                    custInDb.Name = customer.Name;
                    custInDb.MobNo = customer.MobNo;
                }
                _db.SaveChanges();
               
            }
           
            return RedirectToAction("Index");
        }

    }
}