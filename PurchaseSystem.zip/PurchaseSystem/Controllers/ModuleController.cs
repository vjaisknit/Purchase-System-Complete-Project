﻿using PurchaseSystem.Common;
using PurchaseSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PurchaseSystem.Controllers
{
    [Authorize(Roles = "Admin")]
    public class ModuleController : Controller
    {
        ApplicationDbContext _db;
        public ModuleController()
        {
            _db = new ApplicationDbContext();
        }
        // GET: Module
        public ActionResult Index()
        {
            var module = _db.ModuleMsts.ToList();
            return View(module);
        }

        [HttpGet]

        public ActionResult AddUpdateModule()
        {
            return View();
        }

        public ActionResult Edit(int id)
        {
            ModuleMst module = _db.ModuleMsts.FirstOrDefault(a=>a.pk_Moduleid==id);
          
            ViewBag.SubmitValue = "Update";
            return View("AddUpdateModule", module);

        }
        public ActionResult Delete(int id)
        {

            ModuleMst module = _db.ModuleMsts.FirstOrDefault(a => a.pk_Moduleid == id);
            _db.ModuleMsts.Remove(module);
            _db.SaveChanges();
         
            return RedirectToAction("Index");

        }
        [HttpPost]
        public ActionResult AddUpdateModule(ModuleMst module)
        {
            if (module.pk_Moduleid == 0)
            {
                _db.ModuleMsts.Add(module);
                _db.SaveChanges();

            }
            else
            {
                var moduleinDb = _db.ModuleMsts.FirstOrDefault(a => a.pk_Moduleid == module.pk_Moduleid);
                moduleinDb.ModuleName = module.ModuleName;
                moduleinDb.ModuleDesc = module.ModuleDesc;
                moduleinDb.ImageUrl = module.ImageUrl;
                moduleinDb.Action = module.Action;
                moduleinDb.Controller = module.Controller;
                _db.SaveChanges();
            }

            ViewBag.SubmitValue = "Save";
           return RedirectToAction("Index");
        }

    }
}