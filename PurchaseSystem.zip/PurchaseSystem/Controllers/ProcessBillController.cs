﻿using PurchaseSystem.Common;
using PurchaseSystem.DTO;
using PurchaseSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PurchaseSystem.Controllers
{
    [Authorize(Roles = "Admin,GeneralStore,ClothStore")]
    public class ProcessBillController : Controller
    {
        ApplicationDbContext _db;

        public ProcessBillController()
        {
            _db   = new ApplicationDbContext();
        }

        private int ProcessBillList(List<BillsItemTemp> ProductForProcess)
        {
            int trnid = Convert.ToInt32(_db.ProcessBills.Select(p => p.trnId).DefaultIfEmpty(0).Max())+1;
            foreach(BillsItemTemp item in ProductForProcess)
            {
                ProcessBill itemForAdd = new ProcessBill();
                itemForAdd.trnId = trnid;
                itemForAdd.insertedDate = System.DateTime.Now;
                itemForAdd.fk_custid = item.fk_custId;
                itemForAdd.fk_productId = item.Fk_ProductId;
                itemForAdd.PrductCurrentPrice = item.price;
                itemForAdd.ProductQuantity = item.prodQuantity;
                itemForAdd.username = User.Identity.Name;
                _db.ProcessBills.Add(itemForAdd);
                _db.SaveChanges();

                var itemindb = _db.ProductMsts.FirstOrDefault(a=>a.pk_ProductId== item.Fk_ProductId);
                itemindb.productQuantity = (itemindb.productQuantity - item.prodQuantity);
                _db.SaveChanges();
                _db.BillsItemTemps.Remove(item);
                _db.SaveChanges();
                
            }
            return trnid;
        }
        public ActionResult GenearateBill(int pk_custid)
        {
            List<BillsItemTemp> ProductForProcess=new List<BillsItemTemp>();
            if (User.IsInRole("Admin"))
            {
                ProductForProcess = _db.BillsItemTemps.Where(a => a.fk_custId == pk_custid ).ToList();
            }
            else
            {
                ProductForProcess = _db.BillsItemTemps.Where(a => a.fk_custId == pk_custid && a.Username == User.Identity.Name).ToList();
            }

          int trnId=  ProcessBillList(ProductForProcess);

                return RedirectToAction("PrintBill",new { trnid = trnId, custId= pk_custid });
        }

        public ActionResult PrintBill(int trnid,int custId)
        {
            PrintBillDTO printBillDTO = new PrintBillDTO();
            printBillDTO.ProcessBillDto = GetDataForPrintBill(trnid);
            printBillDTO.TotalPrice = printBillDTO.ProcessBillDto.Sum(a => a.PiceByQuantity);
          printBillDTO.CustomerMst = _db.CustomerMsts.FirstOrDefault(a => a.pk_Custid == custId);


            return View(printBillDTO);
        }

        private IEnumerable<ProcessBillDto> GetDataForPrintBill(int trnId)
        {
            IEnumerable<ProcessBillDto> billData = new List<ProcessBillDto>();
            billData = from a in _db.ProcessBills
                       join b in _db.ProductMsts on a.fk_productId equals b.pk_ProductId
                       join c in _db.ProductTypeMsts on b.fk_prodtypeid equals c.pk_prodtypeid
                       where a.trnId == trnId
                       select new ProcessBillDto
                                      {
                                          fk_productType = a.fk_productId,
                                          productName = b.ProductName,
                                          productQuantity = a.ProductQuantity,
                                          productType=c.Description,
                                          productRate=b.sellingUpToPrice,
                                          fk_custid=a.fk_custid,
                                          PiceByQuantity=a.PrductCurrentPrice

                       };

        

            return billData;
        }
    }
}