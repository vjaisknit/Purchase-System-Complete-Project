﻿using PurchaseSystem.Common;
using PurchaseSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PurchaseSystem.Controllers
{
    [Authorize]
    public class TestController : Controller
    {
        ApplicationDbContext context;
        public TestController()
        {
            context = new ApplicationDbContext();
        }
        // GET: Test
        [Authorize(Roles =RollName.G)]
        public ActionResult Index()
        {
            var list=context.TestAuths.ToList();
            return View(list);
        }
        public ActionResult cont()
        {
            return View();
        }
        [Authorize(Roles = RollName.G)]
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [Authorize(Roles = RollName.G)]
        [HttpPost]
        public ActionResult Create(TestAuth t)
        {
            context.TestAuths.Add(t);
            context.SaveChanges();
            return View();
        }
    }
}