﻿using PurchaseSystem.Common;
using PurchaseSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PurchaseSystem.Controllers
{
    [Authorize(Roles = "Admin,GeneralStore,ClothStore")]
    public class HomeController : Controller
    {
        ApplicationDbContext _db;
        public HomeController()
        {
            _db = new ApplicationDbContext();
        }
        public ActionResult Index()
        {
            IEnumerable<ModuleMst> module;
            if (User.IsInRole("Admin"))
            {
                module = _db.ModuleMsts.ToList();
            }
            else if(User.IsInRole("GeneralStore"))
            {
                module = _db.ModuleMsts.Where(a=>a.pk_Moduleid==1);
            }
            else
            {
                module = _db.ModuleMsts.Where(a => a.pk_Moduleid == 2);
            }
            return View(module);
        }

       
    }
}