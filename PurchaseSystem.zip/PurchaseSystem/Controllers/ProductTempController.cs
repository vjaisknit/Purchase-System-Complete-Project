﻿using PurchaseSystem.DTO;

using PurchaseSystem.GeneralStore;
using PurchaseSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PurchaseSystem.Controllers
{
    [Authorize(Roles = "Admin,GeneralStore,ClothStore")]
    public class ProductTempController : Controller
    {
        //ApplicationDbContext _db;
        
        //public ProductTempController()
        //{
        //    _db =new ApplicationDbContext();
        //}

        //private IEnumerable<ProductMstDTO> GetProductList()
        //{
        //    IEnumerable<ProductMstDTO> list;
        //    if (User.IsInRole("Admin"))
        //        {
        //            list. = _db.ProductMsts.ToList();
        //        }
        //        else
        //        {

        //            list = _db.ProductMsts.Where(x => x.username == User.Identity.Name).ToList();
        //        }
        //    return list;
        //}
        //private Gen_PackedItem_mst GetSingleItem(int id)
        //{
        //    Gen_PackedItem_mst item;

        //    if (User.IsInRole("Admin"))
        //    {
        //        item = _db.Gen_PackedItem_msts.SingleOrDefault(a => a.pk_genpacId == id);
        //    }
        //    else
        //    {
        //        item = _db.Gen_PackedItem_msts.SingleOrDefault(a => a.pk_genpacId == id && a.username == User.Identity.Name);

        //    }
        //    return item;
        //}

        //// GET: GenPackItem
        //public ActionResult Index()
        //{
        //    var list = GetDataList();


        //    return View(list);
        //}


        //[HttpGet]
        //public ActionResult SaveUpdateItem()
        //{
        //    Gen_PackedItem_mst item = new Gen_PackedItem_mst();
        //    item.pk_genpacId = 0;
        //    item.fk_prodtypeid = 1;
        //    return View(item);
        //}

        //[HttpPost]
        //public ActionResult SaveUpdateItem(Gen_PackedItem_mst item)
        //{
        //    item.username = User.Identity.Name;
        //    if (!ModelState.IsValid)
        //    {
        //        return View("SaveUpdateItem", item);
        //    }
           
           
        //    if(item.pk_genpacId==0)
        //    {
        //        _db.Gen_PackedItem_msts.Add(item);
        //        _db.SaveChanges();
        //    }
        //    else
        //    {
        //        var itemindb = _db.Gen_PackedItem_msts.FirstOrDefault(a => a.pk_genpacId == item.pk_genpacId);
        //        itemindb.itemName = item.itemName;
        //        itemindb.itemCount = item.itemCount;
        //        itemindb.oriPrice = item.oriPrice;
        //        itemindb.sellingUpToPrice = item.sellingUpToPrice;
        //        _db.SaveChanges();

        //    }
            
            
        //    return RedirectToAction("Index");
        //}

      
        //public ActionResult Edit(int id)
        //{
        //    var item = GetSingleItem(id);
            
        //    if (item == null)
        //        return HttpNotFound();

        //    return View("SaveUpdateItem", item);
        //}
        //[HttpDelete]
        //public ActionResult Delete(int id)
        //{
        //    var item = GetSingleItem(id);
        //    if (item == null)
        //        return HttpNotFound();

        //    _db.Gen_PackedItem_msts.Remove(item);
        //    _db.SaveChanges();
        //    return RedirectToAction("Index");
        //}
    }
}