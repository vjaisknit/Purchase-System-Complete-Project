﻿using PurchaseSystem.Cloth;
using PurchaseSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PurchaseSystem.Controllers
{
    [Authorize(Roles = "Admin,ClothStore")]
    public class CloItemController : Controller
    {
        ApplicationDbContext _db;

        public CloItemController()
        {
            _db = new ApplicationDbContext();
        }
        // GET: GenPackItem

        private IEnumerable<Clo_Item_mst> GetDataList()
        {
            IEnumerable<Clo_Item_mst> list;
            if (User.IsInRole("Admin"))
            {
                list = _db.Clo_Item_msts.ToList();
            }
            else
            {

                list = _db.Clo_Item_msts.Where(x => x.username == User.Identity.Name).ToList();
            }
            return list;
        }
        private Clo_Item_mst GetSingleItem(int id)
        {
            Clo_Item_mst item;

            if (User.IsInRole("Admin"))
            {
                item = _db.Clo_Item_msts.SingleOrDefault(a => a.pk_CloItemId == id);
            }
            else
            {
                item = _db.Clo_Item_msts.SingleOrDefault(a => a.pk_CloItemId == id && a.username == User.Identity.Name);

            }
            return item;
        }
        public ActionResult Index()
        {
            var list = GetDataList();

            return View(list);
        }
        [HttpGet]
        public ActionResult SaveUpdateItem()
        {
            Clo_Item_mst item = new Clo_Item_mst();
            item.pk_CloItemId = 0;
            item.fk_prodtypeid = 3;
            return View("SaveUpdateItem");
        }
        [HttpPost]
        public ActionResult SaveUpdateItem(Clo_Item_mst item)
        {
            item.username = User.Identity.Name;
            if (!ModelState.IsValid)
            {
                return View("SaveUpdateItem", item);
            }

            if (item.pk_CloItemId == 0)
            {
                _db.Clo_Item_msts.Add(item);
                _db.SaveChanges();
            }
            else
            {
                var itemindb = _db.Clo_Item_msts.FirstOrDefault(a => a.pk_CloItemId == item.pk_CloItemId);
                itemindb.itemName = item.itemName;
                itemindb.itemCount = item.itemCount;
                itemindb.oriPrice = item.oriPrice;
                itemindb.sellingUpToPrice = item.sellingUpToPrice;
                _db.SaveChanges();

            }


            return RedirectToAction("Index");
        }
       
        public ActionResult Edit(int id)
        {
            var item = GetSingleItem(id);
            if (item == null)
                return HttpNotFound();

            return View("SaveUpdateItem", item);
        }
        public ActionResult Delete(int id)
        {
            var item = GetSingleItem(id);
           
            if (item == null)
                return HttpNotFound();

            _db.Clo_Item_msts.Remove(item);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}