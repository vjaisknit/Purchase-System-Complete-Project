﻿using PurchaseSystem.GeneralStore;
using PurchaseSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PurchaseSystem.Controllers
{
    [Authorize(Roles = "Admin,GeneralStore")]
    public class GenOpenItemController : Controller
    {
        // GET: GenOpenItem
       
       
            ApplicationDbContext _db;

            public GenOpenItemController()
            {
                _db = new ApplicationDbContext();
            }

        private IEnumerable<Gen_OpenItem_mst> GetDataList()
        {
            IEnumerable<Gen_OpenItem_mst> list;
            if (User.IsInRole("Admin"))
            {
                list = _db.Gen_OpenItem_msts.ToList();
            }
            else
            {

                list = _db.Gen_OpenItem_msts.Where(x => x.username == User.Identity.Name).ToList();
            }
            return list;
        }
        private Gen_OpenItem_mst GetSingleItem(int id)
        {
            Gen_OpenItem_mst item;

            if (User.IsInRole("Admin"))
            {
                item = _db.Gen_OpenItem_msts.SingleOrDefault(a => a.pk_genOpenId == id);
            }
            else
            {
                item = _db.Gen_OpenItem_msts.SingleOrDefault(a => a.pk_genOpenId == id && a.username == User.Identity.Name);

            }
            return item;
        }
        // GET: GenPackItem
        public ActionResult Index()
            {
            var list = GetDataList();

                return View(list);
            }
            [HttpGet]
        public ActionResult SaveUpdateItem()
        {
            Gen_OpenItem_mst item = new Gen_OpenItem_mst();
            item.pk_genOpenId = 0;
            item.fk_prodtypeid = 2;
            return View(item);
        }

        [HttpPost]
            public ActionResult SaveUpdateItem(Gen_OpenItem_mst item)
            {
            item.username = User.Identity.Name;
            if (!ModelState.IsValid)
            {
                return View("SaveUpdateItem", item);
            }

            if (item.pk_genOpenId == 0)
                {
                    _db.Gen_OpenItem_msts.Add(item);
                    _db.SaveChanges();
                }
                else
                {
                    var itemindb = _db.Gen_OpenItem_msts.FirstOrDefault(a => a.pk_genOpenId == item.pk_genOpenId);
                    itemindb.itemName = item.itemName;
                    itemindb.itemWeight = item.itemWeight;
                    itemindb.oriPrice = item.oriPrice;
                    itemindb.sellingUpToPrice = item.sellingUpToPrice;
                    _db.SaveChanges();

                }


                return RedirectToAction("Index");
            }
            
            public ActionResult Edit(int id)
            {
            var item = GetSingleItem(id);
                if (item == null)
                    return HttpNotFound();

                return View("SaveUpdateItem", item);
            }
            public ActionResult Delete(int id)
            {
            var item = GetSingleItem(id);
                if (item == null)
                    return HttpNotFound();


                _db.Gen_OpenItem_msts.Remove(item);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
        }
    }
