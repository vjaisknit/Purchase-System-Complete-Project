﻿using PurchaseSystem.DTO;
using PurchaseSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PurchaseSystem.Controllers
{
        [Authorize(Roles = "Admin,GeneralStore,ClothStore")]
    public class ViewPrcessBillController : Controller
    {
        ApplicationDbContext _db = new ApplicationDbContext();
        public ViewPrcessBillController()
        {

        }

        // GET: ViewPrcessBill
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult BillList()
        {
            IEnumerable<ViewProcessBillListDTO> billList = new List<ViewProcessBillListDTO>();
            if(User.IsInRole("Admin"))
            {
                billList = from T1 in _db.ProcessBills
                           join T2 in _db.CustomerMsts on T1.fk_custid equals T2.pk_Custid
                           
                           group T1 by new { T1.trnId, T2.Name, T2.pk_Custid } into g


                           select new ViewProcessBillListDTO
                           {
                               fk_transactonid = g.Key.trnId,
                               CustomerName = g.Key.Name,
                               fk_custId = g.Key.pk_Custid,
                               totalPrice = g.Sum(t3 => t3.PrductCurrentPrice)
                           };
            }
            else
            {
                billList = from T1 in _db.ProcessBills
                           join T2 in _db.CustomerMsts on T1.fk_custid equals T2.pk_Custid
                           where T1.username == User.Identity.Name
                           group T1 by new { T1.trnId, T2.Name, T2.pk_Custid } into g


                           select new ViewProcessBillListDTO
                           {
                               fk_transactonid = g.Key.trnId,
                               CustomerName = g.Key.Name,
                               fk_custId = g.Key.pk_Custid,
                               totalPrice = g.Sum(t3 => t3.PrductCurrentPrice)
                           };
            }
           
            
            return View(billList);
        }
    }
}