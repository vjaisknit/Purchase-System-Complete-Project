﻿using PurchaseSystem.DTO;
using PurchaseSystem.GeneralStore;
using PurchaseSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PurchaseSystem.Controllers
{
    [Authorize(Roles = "Admin,GeneralStore,ClothStore")]
    public class ProductController : Controller
    {
        ApplicationDbContext _db;
        public ProductController()
        {
            _db = new ApplicationDbContext();
        }
        public ActionResult ProductList()
        {
            IEnumerable<ProductListDTO> _ProductListDTO;
            
            if (User.IsInRole("Admin"))
            {
                _ProductListDTO =   from a in _db.ProductMsts
                                     join b in _db.ProductTypeMsts on a.fk_prodtypeid equals b.pk_prodtypeid
                                     where a.productQuantity>0
                                     select new ProductListDTO
                                     {
                                      pk_productId = a.pk_ProductId,
                                      ProductType = b.Description,
                                      ProductName = a.ProductName,
                                      sellingUpToPrice=a.sellingUpToPrice,
                                      oriPrice = a.oriPrice,
                                      itemQuantity=a.productQuantity
                                      }; 
            }
            else 
            {
                _ProductListDTO = from a in _db.ProductMsts
                                  join b in _db.ProductTypeMsts on a.fk_prodtypeid equals b.pk_prodtypeid
                                  where a.username==User.Identity.Name &&   a.productQuantity > 0
                                  select new ProductListDTO
                                  {
                                      pk_productId = a.pk_ProductId,
                                      ProductType = b.Description,
                                      ProductName = a.ProductName,
                                      sellingUpToPrice = a.sellingUpToPrice,
                                      oriPrice = a.oriPrice,
                                      itemQuantity = a.productQuantity

                                  };
            }
            
            return View(_ProductListDTO);
        }

        // GET: Product
        public ActionResult SaveUpdateProduct()
        {
            ProductMstDTO product = new ProductMstDTO();
            if (User.IsInRole("Admin"))
            {
                product.ProductTypeMst = _db.ProductTypeMsts.ToList();
            }
            else if (User.IsInRole("GeneralStore"))
            {
                product.ProductTypeMst = _db.ProductTypeMsts.Where(a=>a.pk_prodtypeid==1 || a.pk_prodtypeid==2).ToList();
            }
            else
            {
                product.ProductTypeMst = _db.ProductTypeMsts.Where(a => a.pk_prodtypeid == 3).ToList();
            }
            ViewBag.SubmitValue = "Save";
            return View("SaveUpdateProduct",product);
        }

        [HttpPost]
        public ActionResult SaveUpdateProduct(ProductMstDTO product)
        {

            if (product.ProductMst.pk_ProductId == 0)
            {
                ProductMst pro = new ProductMst();
                pro.username = User.Identity.Name;
                pro.fk_prodtypeid = product.ProductMst.fk_prodtypeid;
                pro.ProductName = product.ProductMst.ProductName;
                pro.oriPrice = product.ProductMst.oriPrice;
                pro.sellingUpToPrice = product.ProductMst.sellingUpToPrice;
                pro.productQuantity = product.ProductMst.productQuantity;
                _db.ProductMsts.Add(pro);
                _db.SaveChanges();
            }
            else
            {
                ProductMst productInDb = new ProductMst();
                if (User.IsInRole("Admin"))
                {

                    productInDb = _db.ProductMsts.FirstOrDefault(a => a.pk_ProductId == product.ProductMst.pk_ProductId);
                }
                else
                {
                    productInDb = _db.ProductMsts.FirstOrDefault(a => a.pk_ProductId == product.ProductMst.pk_ProductId && a.username == User.Identity.Name);
                }
                productInDb.username = User.Identity.Name;
                productInDb.fk_prodtypeid = product.ProductMst.fk_prodtypeid;
                productInDb.ProductName = product.ProductMst.ProductName;
                productInDb.oriPrice = product.ProductMst.oriPrice;
                productInDb.sellingUpToPrice = product.ProductMst.sellingUpToPrice;
                productInDb.productQuantity = product.ProductMst.productQuantity;
                _db.SaveChanges();
            }

            return Redirect("ProductList");
        }

        public ActionResult Edit(int id)
        {
            
            ProductMstDTO product = new ProductMstDTO();
            if (User.IsInRole("Admin"))
            {
                product.ProductTypeMst = _db.ProductTypeMsts.ToList();
                product.ProductMst = _db.ProductMsts.FirstOrDefault(a => a.pk_ProductId == id);
            }
            else
            {
                product.ProductTypeMst = _db.ProductTypeMsts.ToList();
                product.ProductMst = _db.ProductMsts.FirstOrDefault(a => a.pk_ProductId == id && a.username==User.Identity.Name);
            }
            ViewBag.SubmitValue = "Update";
            if (product.ProductMst == null)
            {
                return HttpNotFound();
            }
            return View("SaveUpdateProduct", product);
        }

        public ActionResult Delete(int id)
        {
            ProductMstDTO product = new ProductMstDTO();
            if (User.IsInRole("Admin"))
            {
                product.ProductTypeMst = _db.ProductTypeMsts.ToList();
                product.ProductMst = _db.ProductMsts.FirstOrDefault(a => a.pk_ProductId == id);
            }
            else
            {
                product.ProductTypeMst = _db.ProductTypeMsts.ToList();
                product.ProductMst = _db.ProductMsts.FirstOrDefault(a => a.pk_ProductId == id && a.username == User.Identity.Name);
            }
            if (product.ProductMst == null)
            {
                return HttpNotFound();
            }
            _db.ProductMsts.Remove(product.ProductMst);
            _db.SaveChanges();
            return RedirectToAction("ProductList");
        }

    }
}