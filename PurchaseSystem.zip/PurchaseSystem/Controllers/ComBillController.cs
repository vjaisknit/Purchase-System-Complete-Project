﻿using PurchaseSystem.Cloth;
using PurchaseSystem.Common;
using PurchaseSystem.DTO;
using PurchaseSystem.GeneralStore;
using PurchaseSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;

namespace PurchaseSystem.Controllers  
{
    [Authorize(Roles = "Admin,GeneralStore,ClothStore")]
    public class ComBillController : Controller
    {
        ApplicationDbContext _db;

        public ComBillController()
        {
            _db = new ApplicationDbContext();
        }
        // GET: ComBill
        public Com_Bill_DTO GetPageData()
        {
            Com_Bill_DTO Item;
            if (User.IsInRole("Admin"))
            {
                var q = from r in _db.ProductMsts

                        select new ItemDropdownDTO
                        {
                            productId = r.pk_ProductId,
                            ProductNameName = r.ProductName
                        };
                Item = new Com_Bill_DTO
                {
                    ProductList = q.ToList()
                };
            }
            else if(User.IsInRole("GeneralStore"))
            {
                var q = from r in _db.ProductMsts
                        where r.username == User.Identity.Name && r.productQuantity>0 && (r.fk_prodtypeid ==1 || r.fk_prodtypeid == 2)

                        select new ItemDropdownDTO
                        {
                            productId = r.pk_ProductId,
                            ProductNameName = r.ProductName
                        };
                Item = new Com_Bill_DTO
                {
                    ProductList = q.ToList()
                };
            }
            else
            {
                var q = from r in _db.ProductMsts
                        where r.username == User.Identity.Name && r.productQuantity > 0 && (r.fk_prodtypeid == 3 )

                        select new ItemDropdownDTO
                        {
                            productId = r.pk_ProductId,
                            ProductNameName = r.ProductName
                        };
                Item = new Com_Bill_DTO
                {
                    ProductList = q.ToList()
                };
            }

            return (Item);
        }

        [HttpPost]
        public JsonResult GetProductList(int id)
        {
            IEnumerable<ItemDropdownDTO> ProdList;
            if (User.IsInRole("Admin"))
            {
                ProdList = from r in _db.ProductMsts
                           where r.fk_prodtypeid == id
                           select new ItemDropdownDTO
                           {
                               productId = r.pk_ProductId,
                               ProductNameName = r.ProductName
                           };
            }
            else
            {
                ProdList = from r in _db.ProductMsts
                           where r.fk_prodtypeid == id && r.username == User.Identity.Name
                           select new ItemDropdownDTO
                           {
                               productId = r.pk_ProductId,
                               ProductNameName = r.ProductName
                           };
            }



            return Json(ProdList, JsonRequestBehavior.AllowGet);
        }

        public JsonResult CalculatePrice(int prodid, double CountOWeight)
        {
            ProductMst product;

            double price;
            if (User.IsInRole("Admin"))
            {

                product = _db.ProductMsts.FirstOrDefault(a => a.pk_ProductId == prodid);
                price = product.sellingUpToPrice * CountOWeight;

            }
            else
            {
                product = _db.ProductMsts.FirstOrDefault(a => a.pk_ProductId == prodid && a.username == User.Identity.Name);
                price = product.sellingUpToPrice * CountOWeight;

            }
            return Json(price, JsonRequestBehavior.AllowGet);

        }
        [HttpPost]
        public JsonResult Index(string itemname)
        {
            IEnumerable<ItemDropdownDTO> ItemList;
            if (User.IsInRole("Admin"))
            {
                ItemList = from r in _db.ProductMsts
                           where r.ProductName.Contains(itemname)
                           select new ItemDropdownDTO
                           {
                               productId = r.pk_ProductId,
                               ProductNameName = r.ProductName
                           };

            }
            else
            {
                ItemList = from r in _db.ProductMsts
                           where r.ProductName.Contains(itemname) && r.username == User.Identity.Name
                           select new ItemDropdownDTO
                           {
                               productId = r.pk_ProductId,
                               ProductNameName = r.ProductName
                           };
            }
            //List<Country> countryList = _db.Countrys.Where(a => a.CountryName == contryName).ToList();




            return Json(ItemList, JsonRequestBehavior.AllowGet);
        }



        public ActionResult TempBillList(int? id)
        {
            if (id == null || id==0)
            {
                return HttpNotFound();
            }

        


            tempBillProductLists list = new tempBillProductLists();
            if (User.IsInRole("Admin"))
            {  
                list.BillItemTempDTOList = from a in _db.BillsItemTemps
                                           join b in _db.ProductTypeMsts on a.Fk_ProductId equals b.pk_prodtypeid
                                           join c in _db.ProductMsts on a.Fk_ProductId equals c.pk_ProductId
                                           join d in _db.CustomerMsts on a.fk_custId equals d.pk_Custid
                                           where  a.prodQuantity > 0
                                           select new BillItemTempDTO
                                           {
                                             
                                               ProductType = b.Description,
                                               ProductName = c.ProductName,
                                               sellingProductuantity=a.prodQuantity,
                                               RemainingItem = (c.productQuantity - a.prodQuantity),
                                               Selingprice = c.sellingUpToPrice,
                                               SelinTotalgprice = a.price
                                           };
                
                list.CustomerMst = _db.CustomerMsts.FirstOrDefault(a => a.pk_Custid == id );
            }
            else
            {
                list.BillItemTempDTOList = from a in _db.BillsItemTemps
                                         
                                           join c in _db.ProductMsts on a.Fk_ProductId equals c.pk_ProductId
                                           join b in _db.ProductTypeMsts on c.fk_prodtypeid equals b.pk_prodtypeid
                                           join d in _db.CustomerMsts on a.fk_custId equals d.pk_Custid
                                           where a.Username == User.Identity.Name && a.prodQuantity>0
                                           select new BillItemTempDTO
                                           {
                                               fk_tempbillid = a.id,
                                               ProductType = b.Description,
                                               ProductName = c.ProductName,
                                               sellingProductuantity = a.prodQuantity,
                                               RemainingItem = (c.productQuantity - a.prodQuantity),
                                               Selingprice = c.sellingUpToPrice,
                                               SelinTotalgprice = a.price
                                           };
                
                list.CustomerMst = _db.CustomerMsts.FirstOrDefault(a => a.pk_Custid == id && a.Username == User.Identity.Name);
            }
            if(list.BillItemTempDTOList.ToList().Count()>0)
            {
                return View(list);
            }
            else
            {
                TempData["Error"] = "No Item is available for "+list.CustomerMst.Name;
                return RedirectToAction("SaveUpdateBill", new { id =id });
            }

            
        }
        [HttpPost]
        public ActionResult AddProdForBillList(Com_Bill_DTO bill)
        {

            BillsItemTemp billAlreadyAdd = _db.BillsItemTemps.FirstOrDefault(a => a.fk_custId == bill.CustomerMst.pk_Custid &&
             a.Fk_ProductId == bill.Fk_ProductId && a.Username == User.Identity.Name );

            ProductMst pro = _db.ProductMsts.FirstOrDefault(a => a.pk_ProductId == bill.Fk_ProductId);
            if (bill.prodQuantity % 1!=0 && pro.pk_ProductId!=2)
            {
                TempData["Error"] = "Product Quantity should be in number.";
                return RedirectToAction("SaveUpdateBill", new { id = bill.CustomerMst.pk_Custid });
            }

            if (billAlreadyAdd != null && Convert.ToInt32(bill.pk_tempbillid)==0)
            {
                TempData["Error"] = "Product Is Already Added.";
                return RedirectToAction("SaveUpdateBill", new { id = bill.CustomerMst.pk_Custid });
            }
            
            if(Convert.ToInt32(bill.pk_tempbillid) == 0)
            {
                BillsItemTemp tempItem = new BillsItemTemp();

                tempItem.Fk_ProductId = bill.Fk_ProductId;
                tempItem.prodQuantity = bill.prodQuantity;
                tempItem.price = bill.price;
                tempItem.fk_custId = bill.CustomerMst.pk_Custid;
                tempItem.Username = User.Identity.Name;

                _db.BillsItemTemps.Add(tempItem);
                _db.SaveChanges();
            }
            else
            {
                var iteminDb = _db.BillsItemTemps.FirstOrDefault(a => a.id == bill.pk_tempbillid);
                iteminDb.Fk_ProductId = bill.Fk_ProductId;
                iteminDb.prodQuantity = bill.prodQuantity;
                iteminDb.price = bill.price;
                _db.SaveChanges();
            }
            
           
                
                
            
            return RedirectToAction("TempBillList", new {id= bill.CustomerMst.pk_Custid });
        }
       
        [HttpGet]
        public ActionResult SaveUpdateBill(int id)
        {
            Com_Bill_DTO item = new Com_Bill_DTO();
            CustomerMst cust;
            if (User.IsInRole("Admin"))
            {
                cust = _db.CustomerMsts.FirstOrDefault(a => a.pk_Custid == id);
            }
            else
            {
                cust = _db.CustomerMsts.FirstOrDefault(a => a.pk_Custid == id && a.Username == User.Identity.Name);
            }
            if (cust == null)
            {
                return RedirectToAction("Index", "Customer");
            }
            item = GetPageData();
            item.CustomerMst = cust;
            return View("AddProdForBillList", item);
        }

        public ActionResult Delete(int pk_tempitemid, int pk_custid)
        {

         var item=   _db.BillsItemTemps.FirstOrDefault(a => a.id == pk_tempitemid);
            _db.BillsItemTemps.Remove(item);
            _db.SaveChanges();

           
            return RedirectToAction("TempBillList",new { id = pk_custid });
        }
     
        public ActionResult Edit(int id)
        {
            Com_Bill_DTO item = new Com_Bill_DTO();
            CustomerMst cust;
            BillsItemTemp itemForEdit = new BillsItemTemp();
            if(itemForEdit==null)
            {
                return HttpNotFound();
            }
            itemForEdit = _db.BillsItemTemps.FirstOrDefault(a => a.id == id);
            if (User.IsInRole("Admin"))
            {
                cust = _db.CustomerMsts.FirstOrDefault(a => a.pk_Custid == id);
            }
            else
            {
                cust = _db.CustomerMsts.FirstOrDefault(a => a.pk_Custid == itemForEdit.fk_custId && a.Username == User.Identity.Name);
            }
            if (cust == null)
            {
                return HttpNotFound();
            }

            item = GetPageData();
            item.pk_tempbillid = itemForEdit.id;
            item.Fk_ProductId = itemForEdit.Fk_ProductId;
            item.price = itemForEdit.price;
            item.prodQuantity = itemForEdit.prodQuantity;


            item.CustomerMst = cust;
            return View("AddProdForBillList", item);
        }

    }
}

