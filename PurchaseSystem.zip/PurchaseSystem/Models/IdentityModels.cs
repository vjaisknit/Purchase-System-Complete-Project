﻿using System.Data.Entity;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using PurchaseSystem.GeneralStore;
using PurchaseSystem.Cloth;
using PurchaseSystem.Common;

namespace PurchaseSystem.Models
{
    // You can add profile data for the user by adding more properties to your ApplicationUser class, please visit https://go.microsoft.com/fwlink/?LinkID=317594 to learn more.
    public class ApplicationUser : IdentityUser
    {
        public async Task<ClaimsIdentity> GenerateUserIdentityAsync(UserManager<ApplicationUser> manager)
        {
            // Note the authenticationType must match the one defined in CookieAuthenticationOptions.AuthenticationType
            var userIdentity = await manager.CreateIdentityAsync(this, DefaultAuthenticationTypes.ApplicationCookie);
            // Add custom user claims here
            return userIdentity;
        }
    }

    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext()
            : base("DefaultConnection", throwIfV1Schema: false)
        {
        }

        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }

        public DbSet<TestAuth> TestAuths { get; set; }
        public DbSet<ProductMst> ProductMsts { get; set; }
        public DbSet<Clo_Item_mst> Clo_Item_msts { get; set; }
        public DbSet<Gen_OpenItem_mst> Gen_OpenItem_msts { get; set; }

        public DbSet<ProductTypeMst> ProductTypeMsts { get; set; }
        
        public DbSet<Com_Bill> Com_Bills { get; set; }
        public DbSet<BillsItemTemp> BillsItemTemps { get; set; }
        public DbSet<CustomerMst> CustomerMsts { get; set; }
        
        public DbSet<ProcessBill> ProcessBills { get; set; }

        public DbSet<ModuleMst> ModuleMsts { get; set; }

    }
}