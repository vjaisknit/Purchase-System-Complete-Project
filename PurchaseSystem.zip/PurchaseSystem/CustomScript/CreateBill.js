﻿$(document).ready(function() {
    $("#txtItemSearch").autocomplete({
        source: function (request, response) {
            $.ajax({
                url: "/ComBill/Index",
                type: "POST",
                dataType: "json",
                data: { itemname: request.term },
                success: function (data) {
                    response($.map(data, function (item) {
                        return { label: item.ProductNameName, value: item.productId };
                    }))
                }
            })
        }
        , select: function (event, ui) {
            event.preventDefault()
            $("#txtItemSearch").val('');
            $("#Fk_ProductId").val(ui.item.value);

        }, focus: function (event, ui) {
            event.preventDefault();
            $("#txtItemSearch").val('');
        }
    });

    

    
    $("#prodQuantity").change(function () {
      
        $.ajax({
            type: 'POST',
            url: "/ComBill/CalculatePrice",
            dataType: 'json',
            data: { prodid: $("#Fk_ProductId").val(), CountOWeight: $("#prodQuantity").val() },

            success: function (data) {
                $("#price").val(JSON.stringify(data));
            }
        });
    });
       
        });
        //var code = (e.keyCode ? e.keyCode : e.which);
        //if (code == 13) { //Enter keycode
        //    e.preventDefault();
        //    checkInputValue(e);
        //}

   
    

