﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PurchaseSystem.Cloth
{
    public class Clo_Item_mst
    {

        [Key]
        public int pk_CloItemId { get; set; }

        public string username { get; set; }

        [Display(Name = "Product Description")]
        [Required(ErrorMessage = "Please Enter Product Description")]
        public string itemName { get; set; }

        [Display(Name = "Original Price")]
        [Required(ErrorMessage = "Please Enter Product Original Price")]
        public double oriPrice { get; set; }

        [Display(Name = "Selling Price")]
        [Required(ErrorMessage = "Please Enter Product Selling Price")]
        public double sellingUpToPrice { get; set; }


        [Display(Name = "Product Count")]
        [Required(ErrorMessage = "Please Enter Total Number of Product")]
        public int itemCount { get; set; }
        public int fk_prodtypeid { get; set; }

    }
}