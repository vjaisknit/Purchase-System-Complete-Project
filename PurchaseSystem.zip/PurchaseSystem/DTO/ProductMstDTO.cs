﻿using PurchaseSystem.Common;
using PurchaseSystem.GeneralStore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PurchaseSystem.DTO
{
    public class ProductMstDTO
    {
        public ProductMstDTO()
        {
            ProductTypeMst = new List<ProductTypeMst>();
        }
        public IEnumerable<ProductTypeMst> ProductTypeMst { get; set; }

        [Display(Name = "Product Type")]
        public string productType { get; set; }
        public ProductMst ProductMst { get; set; }
    }
}