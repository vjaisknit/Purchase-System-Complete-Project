﻿using PurchaseSystem.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PurchaseSystem.DTO
{
    public class BillItemTempListDTO
    {
        public ProductListDTO ProductListDTO { get; set; }
        public CustomerMst CustomerMst { get; set; }
    }
}