﻿using PurchaseSystem.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PurchaseSystem.DTO
{
    public class Com_Bill_DTO
    {
        public Com_Bill_DTO()
        {
       
            ProductList = new List<ItemDropdownDTO>();
        }
        public int pk_tempbillid { get; set; }
        
        [Display(Name = "Select Product")]
        [Required(ErrorMessage = "Please Select Product")]
        public int Fk_ProductId { get; set; }
       

        [Display(Name = "Quantity in(Kg/Number)")]
        [Required(ErrorMessage = "Please Enter Product Quantity")]
        public double prodQuantity { get; set; }

        [Display(Name = "Product Price")]
        [Required(ErrorMessage = "Please Enter Product Price")]
        public double price { get; set; }

        public CustomerMst CustomerMst { get; set; }
       
        public IEnumerable<ItemDropdownDTO> ProductList { get; set; }
    }
}