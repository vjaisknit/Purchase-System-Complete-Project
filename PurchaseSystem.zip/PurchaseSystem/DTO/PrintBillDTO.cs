﻿using PurchaseSystem.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PurchaseSystem.DTO
{
    public class PrintBillDTO
    {
        public double TotalPrice { get; set; }
        public PrintBillDTO()
        {
            ProcessBillDto = new List<DTO.ProcessBillDto>();
        }
        public CustomerMst CustomerMst { get; set; }
        public IEnumerable<ProcessBillDto> ProcessBillDto { get; set; }
    }
}