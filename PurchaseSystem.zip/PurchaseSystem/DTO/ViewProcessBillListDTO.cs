﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PurchaseSystem.DTO
{
    public class ViewProcessBillListDTO
    {
        

        public string CustomerName { get; set; }

        public int fk_custId { get; set; }
        public int fk_transactonid { get; set; }

        public double totalPrice { get; set; }

        public DateTime SoppingDate { get; set; }
    }
}