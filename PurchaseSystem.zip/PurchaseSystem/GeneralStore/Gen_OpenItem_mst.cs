﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PurchaseSystem.GeneralStore
{
    public class Gen_OpenItem_mst 
    {
        [Key]
        public int pk_genOpenId { get; set; }

        public string username { get; set; }
        [Display(Name = "Product Description")]
        [Required(ErrorMessage = "Please Enter Product Description")]
        public string itemName { get; set; }

        [Display(Name = "Original Price")]
        [Required(ErrorMessage = "Please Enter Product Original Price")]
        public double oriPrice { get; set; }

        [Display(Name = "Selling Price")]
        [Required(ErrorMessage = "Please Enter Product Selling Price")]
        public double sellingUpToPrice { get; set; }

        [Display(Name = "Total Weight")]
        [Required(ErrorMessage = "Please Enter Total Weight of Product")]
        public double itemWeight { get; set; }

        public int fk_prodtypeid { get; set; }
    }
}