﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PurchaseSystem.GeneralStore
{
    public class ProductMst 
    {
        [Key]
        public int pk_ProductId { get; set; }
       
        
        public string username { get; set; }

        public int fk_prodtypeid { get; set; }
        [Display(Name ="Product Description")]
        [Required(ErrorMessage = "Please Enter Product Description")]
        public string ProductName { get; set; }
       
        [Display(Name = "Original Price")]
        [Required(ErrorMessage = "Please Enter Product Original Price")]
        public double oriPrice { get; set; }
     
        [Display(Name = "Selling Price")]
        [Required(ErrorMessage = "Please Enter Product Selling Price")]
        public double sellingUpToPrice { get; set; }
        

        [Display(Name = "Total Item")]
        [Required(ErrorMessage = "Please Enter Count of Product")]
        public double productQuantity { get; set; }

       
    }
}