﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PurchaseSystem.GeneralStore
{
    public class Com_Bill
    {
        [Key]
        public int pk_billid { get; set; }
        public string username { get; set; }

        public  int transactionId { get; set; }
        public int productType { get; set; }
        public int Fk_ProductId  { get; set; }

        public double prodQuantity { get; set; }

        public double  price { get; set; }

        public DateTime InsertedDate { get; set; }


    }
}