﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PurchaseSystem.Common
{
    public class ModuleMst
    {
        [Key]
        public int pk_Moduleid { get; set; }
        public string ModuleName { get; set; }
        public string ModuleDesc { get; set; }

        public string Action { get; set; }

        public string Controller { get; set; }
        public string ImageUrl { get; set; }
    }
}