﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PurchaseSystem.Common
{
    public static class RollName
    {
        public const string A = "Super Admin";
        public const string G = "General Store Shop Keeper";
        public const string C = "Cloth Shop Keeper";
       

    }
}